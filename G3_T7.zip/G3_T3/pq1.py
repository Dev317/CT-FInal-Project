def find_highest_scores_and_paths(edges, weights, start, end):
    answer = 0.
    paths_list = []

    graph = create_graph(edges)

    paths_list = bfs_find_all_paths(graph,start,end,paths_list)

    edge_weight_map = edge_weight(edges, weights)
    score_list = find_score(edge_weight_map, paths_list)

    max_score = 0

    # create a tupple with path and its weight_product
    score_map = []
    for i in range(len(score_list)):
        if score_list[i] > max_score:
            max_score = score_list[i]
        
        score_map.append((paths_list[i],score_list[i]))
    
    answer = max_score
    final_path_list = []

    # find path with max weight_product
    for tupple in score_map:
        if tupple[1] == max_score:
            final_path_list.append(tupple[0])

    return answer, final_path_list

def find_score(edge_weight_map, paths_list):
    final_score = []

    for path in paths_list:
        temp_score = 1
        for i in range(len(path) - 1):
            key = path[i] + "," + path[i+1]
            temp_score *= edge_weight_map[key]
        final_score.append(temp_score)
    
    return final_score

def edge_weight(edges, weights):
    idx = 0
    edge_weight_map = {}
    for edge in edges:

        key = edge[0] + "," + edge[1]
        edge_weight_map[key] = weights[idx]

        idx += 1
    
    return edge_weight_map

#BFS
def bfs_find_all_paths(graph,start,end,paths_list):
    queue = []

    curr_path = []

    curr_path.append(start)
    queue.append(curr_path)
    
    # limit to 10_000 possible paths
    counter = 0

    while len(queue) != 0 and counter < 10000:
        curr_path = queue.pop(0)

        if curr_path[-1] == end:
            paths_list.append(curr_path)
            counter += 1
        
        for neighbour in graph[curr_path[-1]]:
            if neighbour not in curr_path:

                new_path = []
                for i in curr_path:
                    new_path.append(i)

                new_path.append(neighbour)
                queue.append(new_path)

    return paths_list

def create_graph(edges):
    graph = {}
    vertex_list = []
    for edge in edges:
        if edge[0] not in vertex_list:
            vertex_list.append(edge[0])
            graph[edge[0]] = [edge[1]]
        else:
            neighbours = graph[edge[0]]
            neighbours.append(edge[1])
            graph[edge[0]] = neighbours
    
    return graph
