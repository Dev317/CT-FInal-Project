def ranking_func(edges, weights, start):
    graph = create_graph(edges)

    all_possible_vertices = []
    all_reacheable_vertices = []

    for vertices in graph:
        if vertices == start:
            continue
        
        # include only items
        if vertices.find("i") != -1:
            all_possible_vertices.append(vertices)
    
    for vertices in all_possible_vertices:
        visited = []
        if check_if_reachable(graph,start,vertices,visited):
            all_reacheable_vertices.append(vertices)
    
    # print(all_reacheable_vertices)

    result = []
    for vertice in all_reacheable_vertices:
        max_score = find_highest_scores(edges, weights, start, vertice)
        result.append((vertice,max_score))
    
    # sort by item and max_score
    result_sorted = sorted(result, key=lambda tup: (tup[1], -ord(tup[0][1])))
    result_sorted.reverse()

    if len(result_sorted) < 5:
        return result_sorted

    # print(result_sorted)

    ranked = []
    for i in range(5):
        ranked.append(result_sorted[i])
    
    print(ranked)
    return ranked


def check_if_reachable(graph,start,end,visited):

    if start == end:
        return True
    
    if start in visited:
        return False
    
    visited.append(start)

    for neighbour in graph[start]:
        if check_if_reachable(graph,neighbour,end,visited):
            return True
    
    return False

############
def find_highest_scores(edges, weights, start, end):
    answer = 0.
    # paths_list = [[]]
    paths_list = []

    visited = []
    graph = create_graph(edges)

    # paths_list = dfs_find_all_paths(graph,start,end)
    paths_list = bfs_find_all_paths(graph,start,end,paths_list)
    # print(paths_list)

    edge_weight_map = edge_weight(edges, weights)
    score_list = find_score(edge_weight_map, paths_list)
    # print(score_list)

    max_score = 0

    # create a tupple with path and its weight_product
    score_map = []
    for i in range(len(score_list)):
        if score_list[i] > max_score:
            max_score = score_list[i]
        
        score_map.append((paths_list[i],score_list[i]))
    
    answer = max_score

    return answer

def find_score(edge_weight_map, paths_list):
    final_score = []

    for path in paths_list:
        temp_score = 1
        for i in range(len(path) - 1):
            key = path[i] + "," + path[i+1]
            temp_score *= edge_weight_map[key]
        final_score.append(temp_score)
    
    return final_score


def edge_weight(edges, weights):
    idx = 0
    edge_weight_map = {}
    for edge in edges:
        key = edge[0] + "," + edge[1]
        edge_weight_map[key] = weights[idx]
        idx += 1
    return edge_weight_map

#BFS
def bfs_find_all_paths(graph,start,end,paths_list):
    queue = []

    curr_path = []

    curr_path.append(start)
    queue.append(curr_path)
    
    # limit to 1000 possible paths
    counter = 0

    while len(queue) != 0 and counter < 1000:
        curr_path = queue.pop(0)

        if curr_path[-1] == end:
            paths_list.append(curr_path)
            counter += 1
        
        for neighbour in graph[curr_path[-1]]:
            if neighbour not in curr_path:

                new_path = []
                for i in curr_path:
                    new_path.append(i)

                new_path.append(neighbour)
                queue.append(new_path)

    return paths_list

def create_graph(edges):
    graph = {}
    vertex_list = []
    for edge in edges:
        if edge[0] not in vertex_list:
            vertex_list.append(edge[0])
            graph[edge[0]] = [edge[1]]
        else:
            neighbours = graph[edge[0]]
            neighbours.append(edge[1])
            graph[edge[0]] = neighbours
    
    return graph